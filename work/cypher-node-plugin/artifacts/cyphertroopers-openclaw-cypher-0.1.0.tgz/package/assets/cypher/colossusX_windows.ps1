# colossusX_windows.ps1

$ErrorActionPreference = "Stop"
# Handle native failures explicitly, including when the caller enables the
# PowerShell 7 native-command error preference.
$PSNativeCommandUseErrorActionPreference = $false
[string[]]$CypherExtraArgs = @($args)

$SCRIPT_DIR = $PSScriptRoot

if ([string]::IsNullOrWhiteSpace($SCRIPT_DIR)) {
  $SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
}

if ([string]::IsNullOrWhiteSpace($SCRIPT_DIR)) {
  $SCRIPT_DIR = (Get-Location).Path
}

if ([string]::IsNullOrWhiteSpace($env:CYPHER_DATADIR)) {
  $DATADIR = Join-Path $SCRIPT_DIR "chaindbname"
} elseif ([System.IO.Path]::IsPathRooted($env:CYPHER_DATADIR)) {
  $DATADIR = $env:CYPHER_DATADIR
} else {
  $DATADIR = Join-Path $SCRIPT_DIR $env:CYPHER_DATADIR
}
$CypherIpcArgs = @()
if (![string]::IsNullOrWhiteSpace($env:CYPHER_IPC_PATH)) {
  $CypherIpcArgs = @("--ipcpath", $env:CYPHER_IPC_PATH)
}
$CypherRpcArgs = @("--ws", "--http", "--allow-insecure-unlock")
if ($env:CYPHER_RPC_ENABLED -ceq "0") {
  $CypherRpcArgs = @()
}
$CypherConsoleArgs = @("console")
if ($env:CYPHER_HEADLESS -ceq "1") {
  $CypherConsoleArgs = @()
}
$CYPHER_BIN = Join-Path $SCRIPT_DIR "build\bin\cypher.exe"
$GENESIS_FILE = Join-Path $SCRIPT_DIR "genesis.json"

function Normalize-IpLiteral {
  param([string]$Address)

  if ([string]::IsNullOrWhiteSpace($Address)) {
    return ""
  }

  $Value = $Address.Trim()

  if ($Value.StartsWith("[") -and $Value.EndsWith("]")) {
    return $Value.Substring(1, $Value.Length - 2)
  }

  return $Value
}

function Format-EndpointHost {
  param([string]$Address)

  $Value = Normalize-IpLiteral $Address

  if ($Value.Contains(":")) {
    return "[$Value]"
  }

  return $Value
}

if ([string]::IsNullOrWhiteSpace($env:CYPHER_BOOTNODE_HOST)) {
  $BOOTNODE_HOST = "13.140.169.170"
} else {
  $BOOTNODE_HOST = Normalize-IpLiteral $env:CYPHER_BOOTNODE_HOST
}

$BOOTNODE_ADDR = Format-EndpointHost $BOOTNODE_HOST

if ([string]::IsNullOrWhiteSpace($env:CYPHER_RPC_BIND)) {
  $RPC_BIND = "0.0.0.0"
} else {
  $RPC_BIND = $env:CYPHER_RPC_BIND
}

if ([string]::IsNullOrWhiteSpace($env:CYPHER_WS_BIND)) {
  $WS_BIND = $RPC_BIND
} else {
  $WS_BIND = $env:CYPHER_WS_BIND
}

$PEER_DIR = Join-Path $DATADIR "cypher"
$CHAINDATA_DIR = Join-Path $PEER_DIR "chaindata"
$STATIC_NODES_FILE = Join-Path $PEER_DIR "static-nodes.json"
$TRUSTED_NODES_FILE = Join-Path $PEER_DIR "trusted-nodes.json"

$BOOTNODES_ARRAY = @(
  "enode://e10a90e9c7d077002d4d56b88943b8dfbca1d6490bb92c8202e6acb68ef23b521bf187fb40c07eed2f453f3782e8c53ca5a4ec1d34a4454960143501df8c4b95@${BOOTNODE_ADDR}:6000",
  "enode://0c8a37a7803c358d8ae68784ef247a0c8b4df542d925b23491dd92f4c2172a146a124171ec5bbdcc2e5932e4cead917505ce3b5dbd72155a78e830ebd8e37b07@${BOOTNODE_ADDR}:6001",
  "enode://65ebdea1e99c440bb5463b68565e7422ab332ef8d1472daa956d23b70245ef9703c23ea110291eeb6fe0b60c7e55fed08f76e71fb980ae9b3e2fe583a115e7f3@${BOOTNODE_ADDR}:6002",
  "enode://c7a724e53dc21ff034e628bb4e50d720e6bbc276bd17cc15cc9a28149a5f0a6bd90c0e50f862f5546fa9bc153c7ea818cdf3d133d06356e76b99726754a6b3da@${BOOTNODE_ADDR}:6003",
  "enode://a99ba2027de40c50220e45af60698d7e04237c128258065261fae82cef723837f00ce8611c3164b9efdfc15f0480a308ac65058db9a3abdf83aae05604c9a495@${BOOTNODE_ADDR}:6004",
  "enode://8a3aad9282f773ddd38b05516c2c5847ef168b8b5095f57312a458e0a5b358655cb971d1ba193999b0454fc4ae5642f31c6f6bce311a8da11b0a6d9940719a5e@${BOOTNODE_ADDR}:6005",
  "enode://7eb6bd844e05f64114ea6e6f06ae04e075df0a8a6d783620344f3535df2f2115ad2ad09dab69cf3515ee2d0ac50379c0825a0abfa5a50216d8e4b97823acbd67@${BOOTNODE_ADDR}:6006"
)

$BOOTNODES = $BOOTNODES_ARRAY -join ","

Write-Host "==> Script dir: $SCRIPT_DIR"
Write-Host "==> Datadir: $DATADIR"

if (!(Test-Path -Path $CYPHER_BIN -PathType Leaf)) {
  Write-Host "ERROR: Cypher binary not found: $CYPHER_BIN"
  exit 1
}

if (!(Test-Path -Path $GENESIS_FILE -PathType Leaf)) {
  Write-Host "ERROR: Genesis file not found: $GENESIS_FILE"
  exit 1
}

# Relay defaults ON for this Common launcher. Explicit node flags override the
# environment; keep caller arguments intact and validate before genesis init.
$RelaySetting = $env:CYPHER_BROWSER_RELAY
if ([string]::IsNullOrEmpty($RelaySetting)) { $RelaySetting = "1" }
if ($RelaySetting -cnotin @("0", "1")) {
  Write-Host "ERROR: CYPHER_BROWSER_RELAY must be 0 or 1"
  exit 1
}
$RelayEnabled = $RelaySetting -ceq "1"
$RelayConfig = $env:CYPHER_BROWSER_RELAY_CONFIG
if ([string]::IsNullOrEmpty($RelayConfig)) {
  $RelayConfig = Join-Path $SCRIPT_DIR "config\browser-relay\common-mine.json"
}
$RelayConfigFromCLI = $false
for ($i = 0; $i -lt $CypherExtraArgs.Count; $i++) {
  $Argument = $CypherExtraArgs[$i]
  if ($Argument -ceq "--") { break }
  if ($Argument -ceq "--browser.public-relay") {
    $RelayEnabled = $true
  } elseif ($Argument.StartsWith("--browser.public-relay=", [StringComparison]::Ordinal)) {
    $Value = $Argument.Substring("--browser.public-relay=".Length)
    if ($Value -cin @("1", "t", "T", "true", "TRUE", "True")) {
      $RelayEnabled = $true
    } elseif ($Value -cin @("0", "f", "F", "false", "FALSE", "False")) {
      $RelayEnabled = $false
    } else {
      Write-Host "ERROR: Invalid --browser.public-relay boolean: $Value"
      exit 1
    }
  } elseif ($Argument -ceq "--browser.public-relay.config") {
    if ($i + 1 -ge $CypherExtraArgs.Count -or $CypherExtraArgs[$i + 1].StartsWith("--")) {
      Write-Host "ERROR: --browser.public-relay.config requires an absolute file path"
      exit 1
    }
    $i++
    $RelayConfig = $CypherExtraArgs[$i]
    $RelayConfigFromCLI = $true
  } elseif ($Argument.StartsWith("--browser.public-relay.config=", [StringComparison]::Ordinal)) {
    $RelayConfig = $Argument.Substring("--browser.public-relay.config=".Length)
    $RelayConfigFromCLI = $true
  }
}
$CypherRelayArgs = @()
if ($RelayEnabled) {
  # A root-relative or drive-relative Windows path is not an absolute CLI path.
  $AbsoluteConfig = [System.IO.Path]::IsPathRooted($RelayConfig)
  if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
    $AbsoluteConfig = $RelayConfig -match '^(?:[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+(?:\\|$))'
  }
  if ($RelayConfigFromCLI -and !$AbsoluteConfig) {
    Write-Host "ERROR: --browser.public-relay.config requires an absolute file path"
    exit 1
  }
  if (!(Test-Path -LiteralPath $RelayConfig -PathType Leaf)) {
    Write-Host "ERROR: Browser relay config not found: $RelayConfig"
    exit 1
  }
  $RelayConfig = (Resolve-Path -LiteralPath $RelayConfig).ProviderPath
  $CypherRelayArgs = @("--browser.public-relay", "--browser.public-relay.config", $RelayConfig)
  Write-Host "==> Browser relay: ON ($RelayConfig)"
} else {
  if ($RelayConfigFromCLI) {
    Write-Host "ERROR: --browser.public-relay.config requires --browser.public-relay"
    exit 1
  }
  Write-Host "==> Browser relay: OFF"
}

if (!(Test-Path -Path $DATADIR -PathType Container)) {
  New-Item -ItemType Directory -Force -Path $DATADIR | Out-Null
}

if (!(Test-Path -Path $CHAINDATA_DIR -PathType Container)) {
  Write-Host "==> Chaindata not found: $CHAINDATA_DIR"
  Write-Host "==> Init genesis"

  & $CYPHER_BIN `
    --datadir "$DATADIR" `
    init "$GENESIS_FILE"
  if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
  }
} else {
  Write-Host "==> Existing chaindata detected: $CHAINDATA_DIR"
  Write-Host "==> Skip init genesis"
}

if (!(Test-Path -Path $PEER_DIR -PathType Container)) {
  New-Item -ItemType Directory -Force -Path $PEER_DIR | Out-Null
}

if (!(Test-Path -Path $STATIC_NODES_FILE -PathType Leaf)) {
  Write-Host "==> static-nodes.json not found"
  Write-Host "==> Write static peers: $STATIC_NODES_FILE"

  $StaticNodeLines = for ($i = 0; $i -lt $BOOTNODES_ARRAY.Count; $i++) {
    $Comma = if ($i -lt $BOOTNODES_ARRAY.Count - 1) { "," } else { "" }
    "  `"$($BOOTNODES_ARRAY[$i])`"$Comma"
  }

  $StaticNodesJson = "[`r`n" + ($StaticNodeLines -join "`r`n") + "`r`n]"

  $Utf8NoBom = New-Object System.Text.UTF8Encoding $false
  [System.IO.File]::WriteAllText($STATIC_NODES_FILE, $StaticNodesJson, $Utf8NoBom)

} else {
  Write-Host "==> Existing static-nodes.json detected: $STATIC_NODES_FILE"
  Write-Host "==> Skip static-nodes.json generation"
}

if (!(Test-Path -Path $TRUSTED_NODES_FILE -PathType Leaf)) {
  Write-Host "==> trusted-nodes.json not found"
  Write-Host "==> Copy static-nodes.json to trusted-nodes.json"

  Copy-Item -Path $STATIC_NODES_FILE -Destination $TRUSTED_NODES_FILE -Force
} else {
  Write-Host "==> Existing trusted-nodes.json detected: $TRUSTED_NODES_FILE"
  Write-Host "==> Skip trusted-nodes.json generation"
}

Write-Host "==> Start Cypher node"
Write-Host "==> Bootnode host: $BOOTNODE_HOST"
Write-Host "==> RPC bind: $RPC_BIND"
Write-Host "==> WS bind: $WS_BIND"

# Additional flags apply to the node, not genesis initialization. The config's
# socketPath:auto is resolved by the native binary to its owner-only named pipe.
$CypherNodeArgs = @(
  "--verbosity", "1",
  "--rnetport", "7200",
  "--syncmode", "full",
  "--ws.addr", $WS_BIND,
  "--ws.port", "9251",
  "--ws.origins", "*",
  "--metrics",
  "--http.addr", $RPC_BIND,
  "--http.port", "8000",
  "--http.api", "eth,web3,net,txpool",
  "--http.corsdomain", "*",
  "--port", "6000",
  "--datadir", $DATADIR,
  "--networkid", "10101919",
  "--gcmode", "archive",
  "--bootnodes", $BOOTNODES
) + $CypherRpcArgs + $CypherIpcArgs + $CypherRelayArgs + $CypherExtraArgs + $CypherConsoleArgs

& $CYPHER_BIN @CypherNodeArgs
exit $LASTEXITCODE
